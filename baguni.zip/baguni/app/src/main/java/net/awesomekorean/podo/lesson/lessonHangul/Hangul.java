package net.awesomekorean.podo.lesson.lessonHangul;

public interface Hangul {

    String[] getHangul();

    String[] getHangulExplain();

    String getHangulIntro();

}
