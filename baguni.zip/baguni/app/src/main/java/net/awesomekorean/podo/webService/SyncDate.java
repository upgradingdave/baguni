package net.awesomekorean.podo.webService;

public class SyncDate {
    private String dateNow;
    private String dateLastSync;

    public String getDateNow() {
        return dateNow;
    }

    public void setDateNow(String dateNow) {
        this.dateNow = dateNow;
    }

    public String getDateLastSync() {
        return dateLastSync;
    }

    public void setDateLastSync(String dateLastSync) {
        this.dateLastSync = dateLastSync;
    }
}
